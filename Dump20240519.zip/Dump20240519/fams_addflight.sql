-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: fams
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addflight`
--

DROP TABLE IF EXISTS `addflight`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addflight` (
  `flightCode` varchar(30) NOT NULL,
  `flightName` varchar(20) NOT NULL,
  `from_` varchar(30) DEFAULT NULL,
  `to_` varchar(30) DEFAULT NULL,
  `price` int DEFAULT NULL,
  PRIMARY KEY (`flightCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addflight`
--

LOCK TABLES `addflight` WRITE;
/*!40000 ALTER TABLE `addflight` DISABLE KEYS */;
INSERT INTO `addflight` VALUES ('f0001','Flyhigh','Gorakhpur','Ayodhya',20000),('f0002','Flyhigh','Ayodhya','Gorakhpur',20000),('f0003','Air India','Agara','Prayagraj',15000),('f0005','Indigo','Lucknow','Gorakhpur',10000),('f0006','Flyhigh','Kanpur','Ayodhya',15000),('f0007','Flyhigh','Agara','Kanpur',15000),('f0008','Flyhigh','Agara','Varanasi',15000),('f0009','Flyhigh','Kushinagar','Ayodhya',25000),('f0010','Air India','Gorakhpur','Ayodhya',5000),('f0011','Indigo','Ayodhya','Gorakhpur',5000),('f0012','Flyhigh','Lucknow','Gorakhpur',3000),('f0013','Flyhigh','Kushinagar','Lucknow',3000),('f0014','Air India','Varanasi','Ayodhya',6000),('f0015','Air India','Kanpur','Gorakhpur',5000),('f0016','Flyhigh','Gorakhpur','Ayodhya',7000);
/*!40000 ALTER TABLE `addflight` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-19 21:20:55
