-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: fams
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `passenger`
--

DROP TABLE IF EXISTS `passenger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `passenger` (
  `username` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `age` int NOT NULL,
  `dob` varchar(20) DEFAULT NULL,
  `gender` char(20) DEFAULT NULL,
  `contactNo` varchar(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `nationality` varchar(20) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `passportNo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passenger`
--

LOCK TABLES `passenger` WRITE;
/*!40000 ALTER TABLE `passenger` DISABLE KEYS */;
INSERT INTO `passenger` VALUES ('abhimanu22','Abhimanu Singh',38,'08-05-1988','Male','8756876587','abhimanu@gmail.com','Indian','Sahajanwa Gorakhpur','P87564367'),('deepu22','Deepu Patel',24,'01-03-1998','Male','8756896745','deepu@gmail.com','Indian','Maharajganj',''),('harishankar22','Harishankar Gupta',48,'01-02-1992','Male','8765439867','harshishankar@gmail.com','Indian','Gorakhpur Uttar Pradesh',''),('harsh22','Harsh Shukla',21,'01-04-2002','Male','8756401505','harshsingh@gmail.com','Indian','Padri Bazar Gorakhur',''),('himanshu33','Himanshu Singh',19,'01-03-2004','Male','8127293885','himanshusingh@gmail.com','Indian','Padri  Bazar Gorakhpur',''),('priyanshu15','Priyanshu Singh',18,'15-07-2005','Male','7269052775','priyanshusingh@gmail.com','Indian','Padri  Bazar Gorakhpur','P54643534'),('raj22','Raj Singh',19,'21-12-2004','Male','9839982919','rajsingh@gmail.com','Indian','Sirsia No 2 Kushinagar','P8767757'),('satyam22','Satyam Shukla',21,'01-06-2003','Male','8756788956','satyamshukla@gmail.com','Indian','Padri Bazar Gorakhpur','P7687654'),('shivendra22','Shivendra Singh',21,'01-02-2002','Male','6204152436','shivendra@gmail.com','Indian','Dharmashala Gorakhpur','');
/*!40000 ALTER TABLE `passenger` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-19 21:20:55
