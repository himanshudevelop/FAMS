
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
    import java.sql.*;

public class ConnectionProvider {
    
    public static Connection getCon()
    {
        
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/fams","root","1947");
            return con;
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        
        }
        return null;
    }

    
}


