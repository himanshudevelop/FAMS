
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.ByteArrayOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;
import org.krysalis.barcode4j.impl.code128.Code128Bean;
import org.krysalis.barcode4j.impl.upcean.EAN13Bean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author singh
 */
//Ticket means Collect Ticket
public class Ticket extends javax.swing.JFrame {
    /**
     * Creates new form Ticket
     */
   
    public Ticket() {
        
        initComponents();
        getRecords();
         generateRandomAlphabet();
         
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1326, 666); // Initial size, can be changed as needed
        setResizable(true); // Allow resizing
        
        setTitle("Collect Ticket");
        getRootPane().setBorder(BorderFactory.createLineBorder(Color.black, 2));
         
       this.getContentPane().setBackground(Color.decode("#e8e6e6"));
      JLabel qrlabel = new JLabel(); // Initialize qrlabel
      generateQRCodeFromDatabase();
    }
    
    private void generateRandomAlphabet() {
       // Random object create karein
    Random random = new Random();
    // A se lekar Z tak ke random alphabet generate karein
    char randomAlphabet = (char) ('A' + random.nextInt(26));
    // gateText field mein random alphabet set karein
    gateText.setText(String.valueOf(randomAlphabet));

        }

  public void getRecords() {
    try {
        // Database connection establish karein
        Connection con = ConnectionProvider.getCon();
        // SQL query taiyar karein jo sabse latest record ko retrieve karta hai
        // journeyDate aur journeyTime ke basis par order kiya gaya hai, aur sirf ek record hi retrieve karta hai LIMIT 1 ke zariye
        PreparedStatement pst = con.prepareStatement("SELECT * FROM bookTicket ORDER BY journeyDate DESC, journeyTime DESC LIMIT 1");
        // Query execute karein
        ResultSet rs = pst.executeQuery();

        // Agar record milta hai
        if (rs.next()) {
            // Retrieve kiye gaye data ko appropriate text fields mein set karein
            pnrText.setText(rs.getString("pnr"));
            nameText.setText(rs.getString("name_"));
            nameTxt.setText(rs.getString("name_"));
            flightNameText.setText(rs.getString("flightName"));
            flightNameTxt.setText(rs.getString("flightName"));
            classText.setText(rs.getString("class"));
            classTxt.setText(rs.getString("class"));
            fromText.setText(rs.getString("from_"));
            fromTxt.setText(rs.getString("from_"));
            toText.setText(rs.getString("to_"));
            toTxt.setText(rs.getString("to_"));
            seatText.setText(rs.getString("seat"));
            seatTxt.setText(rs.getString("seat"));
            totalPayText.setText(rs.getString("totalPay"));
            totalPayTxt.setText(rs.getString("totalPay"));
            dateText.setText(rs.getString("journeyDate"));
            timeText.setText(rs.getString("journeyTime"));
        }
    } catch (Exception e) {
        // Exception ka handle karein aur stack trace print karein
        e.printStackTrace();
    }
        }
 
  private void generateQRCodeFromDatabase() {
    try {
        // Database connection establish karein
        Connection con = ConnectionProvider.getCon();
        // SQL query taiyar karein jo sabse latest record ko retrieve karta hai
        // journeyDate aur journeyTime ke basis par order kiya gaya hai, aur sirf ek record hi retrieve karta hai LIMIT 1 ke zariye
        PreparedStatement pst = con.prepareStatement("SELECT pnr, username,name_,from_,to_,journeyDate,journeyTime FROM bookTicket ORDER BY journeyDate DESC, journeyTime DESC LIMIT 1");
        // Query execute karein
        ResultSet rs = pst.executeQuery();

        // Agar record milta hai
        while (rs.next()) {
            // Record se data retrieve karein
            String pnr = rs.getString("pnr");
            String username = rs.getString("username");
            String name = rs.getString("name_");
            String from = rs.getString("from_");
            String to = rs.getString("to_");
            String date = rs.getString("journeyDate");
            String time = rs.getString("journeyTime");

            
            // Concatenate pnr, username, name, from, to aur airline name for QR code text
            String text = " PNR: " + pnr + ", \nUsername: " + username + ", \nName: " + name + ", \nFrom: " + from + ", \nTo: " + to +", \nDate: " + date + ", \nTime: " + time +   "\nIssued By FLYHIGH AIRLINES";
            
            // Generate QR code with concatenated text
            generateQRCode(text, 160, 150);
        }
    } catch (Exception e) {
        // Exception ka handle karein aur error message print karein
        System.err.println("Error generating QR code from database: " + e.getMessage());
        e.printStackTrace();
    }
  }

  private void generateQRCode(String text, int width, int height) {
    // QR code ke liye hints ko setup karein
    Map<EncodeHintType, Object> hints = new HashMap<>();
    hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L); // Error correction level set karein
    hints.put(EncodeHintType.CHARACTER_SET, "UTF-8"); // Character set UTF-8 mein set karein

    try {
        // Text se QR code generate karein
        BitMatrix bitMatrix = new MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, width, height, hints);
        // BufferedImage create karein jismein QR code render hoga
        BufferedImage qrImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        // QR code ko BufferedImage mein render karein
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                // BitMatrix se har pixel ko set karein
                qrImage.setRGB(x, y, bitMatrix.get(x, y) ? 0xFF000000 : 0xFFFFFFFF); // Black ya white color set karein pixel ke basis par
            }
        }

        // qrText JLabel ko QR code image ke saath update karein
        qrText.setIcon(new ImageIcon(qrImage));
        qrText.setSize(width, height); // qrText ka size set karein
    } catch (Exception e) {
        // Exception handle karein aur error message print karein
        System.err.println("Error generating QR code: " + e.getMessage());
        e.printStackTrace();
    }
   }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ticketPanel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        nameText = new javax.swing.JLabel();
        flightNameText = new javax.swing.JLabel();
        classText = new javax.swing.JLabel();
        dateText = new javax.swing.JLabel();
        timeText = new javax.swing.JLabel();
        fromText = new javax.swing.JLabel();
        toText = new javax.swing.JLabel();
        seatText = new javax.swing.JLabel();
        totalPayText = new javax.swing.JLabel();
        pnrText = new javax.swing.JLabel();
        nameTxt = new javax.swing.JLabel();
        fromTxt = new javax.swing.JLabel();
        toTxt = new javax.swing.JLabel();
        flightNameTxt = new javax.swing.JLabel();
        classTxt = new javax.swing.JLabel();
        seatTxt = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        gateText = new javax.swing.JLabel();
        totalPayTxt = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        qrText = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel5 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        backBt = new javax.swing.JButton();
        printBt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel3.setText("Passenger Name:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 6, -1, -1));

        jLabel4.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel4.setText("Flight Name:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(287, 6, -1, -1));

        jLabel6.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel6.setText("Class:");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(506, 6, -1, -1));

        jLabel7.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel7.setText("Date:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(655, 6, -1, -1));

        jLabel8.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel8.setText("Time:");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(816, 6, -1, -1));

        jLabel12.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel12.setText("Passenger Name:");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 10, -1, -1));

        jLabel13.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel13.setText("From:");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 104, -1, -1));

        jLabel14.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel14.setText("To:");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 165, -1, -1));

        jLabel15.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel15.setText("Seat:");
        jPanel1.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(352, 104, -1, -1));

        jLabel16.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel16.setText("Pay");
        jPanel1.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 104, -1, -1));

        jLabel17.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel17.setText("PNR:");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(664, 104, -1, -1));

        jLabel18.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel18.setText("To:");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 130, -1, -1));

        jLabel19.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel19.setText("From:");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 80, -1, -1));

        jLabel20.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel20.setText("Flight Name:");
        jPanel1.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 170, -1, -1));

        jLabel21.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel21.setText("Seat:");
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 260, -1, -1));

        jLabel22.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel22.setText("Pay");
        jPanel1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 260, -1, -1));

        jLabel23.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel23.setText("Class:");
        jPanel1.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 170, -1, -1));

        nameText.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        nameText.setText("...............");
        jPanel1.add(nameText, new org.netbeans.lib.awtextra.AbsoluteConstraints(43, 41, -1, -1));

        flightNameText.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        flightNameText.setText("...............");
        jPanel1.add(flightNameText, new org.netbeans.lib.awtextra.AbsoluteConstraints(297, 41, 180, -1));

        classText.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        classText.setText("...........");
        jPanel1.add(classText, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 41, 123, -1));

        dateText.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        dateText.setText(".........");
        jPanel1.add(dateText, new org.netbeans.lib.awtextra.AbsoluteConstraints(651, 41, 138, -1));

        timeText.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        timeText.setText("........");
        jPanel1.add(timeText, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 40, 120, -1));

        fromText.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        fromText.setText("...............");
        jPanel1.add(fromText, new org.netbeans.lib.awtextra.AbsoluteConstraints(115, 108, -1, -1));

        toText.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        toText.setText("...............");
        jPanel1.add(toText, new org.netbeans.lib.awtextra.AbsoluteConstraints(109, 169, -1, -1));

        seatText.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        seatText.setText("......");
        jPanel1.add(seatText, new org.netbeans.lib.awtextra.AbsoluteConstraints(362, 144, -1, -1));

        totalPayText.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        totalPayText.setText("......");
        jPanel1.add(totalPayText, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 144, 88, -1));

        pnrText.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        pnrText.setText("............");
        jPanel1.add(pnrText, new org.netbeans.lib.awtextra.AbsoluteConstraints(664, 144, 142, -1));

        nameTxt.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        nameTxt.setText("...............");
        jPanel1.add(nameTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 40, 220, -1));

        fromTxt.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        fromTxt.setText("...............");
        jPanel1.add(fromTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 90, -1, -1));

        toTxt.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        toTxt.setText("...............");
        jPanel1.add(toTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 130, -1, -1));

        flightNameTxt.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        flightNameTxt.setText("...............");
        jPanel1.add(flightNameTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 220, 148, -1));

        classTxt.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        classTxt.setText(".........");
        jPanel1.add(classTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 220, 125, -1));

        seatTxt.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        seatTxt.setText("......");
        jPanel1.add(seatTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 300, 80, -1));

        jLabel37.setFont(new java.awt.Font("Monospaced", 1, 26)); // NOI18N
        jLabel37.setText("Gate No.");
        jPanel1.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 210, 140, -1));

        gateText.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        gateText.setText("........");
        jPanel1.add(gateText, new org.netbeans.lib.awtextra.AbsoluteConstraints(698, 250, 80, -1));

        totalPayTxt.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        totalPayTxt.setText("......");
        jPanel1.add(totalPayTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 300, 80, -1));

        jLabel38.setFont(new java.awt.Font("Monospaced", 0, 22)); // NOI18N
        jLabel38.setText("Issued By");
        jPanel1.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(121, 242, -1, -1));

        jLabel39.setFont(new java.awt.Font("Tahoma", 1, 26)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(0, 204, 255));
        jLabel39.setText("FLYHIGH AIRLINES");
        jPanel1.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(57, 281, 261, -1));
        jPanel1.add(qrText, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 180, 160, 160));

        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 10, 10, 320));

        jPanel5.setBackground(new java.awt.Color(0, 204, 255));
        jPanel5.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel5.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                jPanel5ComponentShown(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fams go.png"))); // NOI18N

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 34)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("  FLYHIGH AIRLINES  ");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 34)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("  BOARDING PASS  ");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9)
                .addGap(212, 212, 212)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(55, 55, 55))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addContainerGap())
        );

        javax.swing.GroupLayout ticketPanelLayout = new javax.swing.GroupLayout(ticketPanel);
        ticketPanel.setLayout(ticketPanelLayout);
        ticketPanelLayout.setHorizontalGroup(
            ticketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ticketPanelLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(ticketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1327, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        ticketPanelLayout.setVerticalGroup(
            ticketPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ticketPanelLayout.createSequentialGroup()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(ticketPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, -1, 448));

        jPanel7.setBackground(new java.awt.Color(0, 204, 255));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("  Ticket  ");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fams go.png"))); // NOI18N

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fams go.png"))); // NOI18N

        jLabel41.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel41.setText("Welcome to Flyhigh Airlines");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(120, 120, 120)
                .addComponent(jLabel5)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 165, Short.MAX_VALUE)
                        .addComponent(jLabel41)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 155, Short.MAX_VALUE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel11)
                        .addGap(327, 327, 327)))
                .addComponent(jLabel2)
                .addGap(124, 124, 124))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel41)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel11))
                    .addComponent(jLabel5)
                    .addComponent(jLabel2))
                .addGap(0, 7, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1327, 120));

        backBt.setBackground(new java.awt.Color(0, 0, 0));
        backBt.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        backBt.setForeground(new java.awt.Color(255, 255, 255));
        backBt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/back1.png"))); // NOI18N
        backBt.setText("Back");
        backBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtActionPerformed(evt);
            }
        });
        getContentPane().add(backBt, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 610, -1, -1));

        printBt.setBackground(new java.awt.Color(0, 0, 0));
        printBt.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        printBt.setForeground(new java.awt.Color(255, 255, 255));
        printBt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/print.png"))); // NOI18N
        printBt.setText("Print");
        printBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printBtActionPerformed(evt);
            }
        });
        getContentPane().add(printBt, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 610, 134, -1));

        setSize(new java.awt.Dimension(1326, 687));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jPanel5ComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jPanel5ComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel5ComponentShown

    private void backBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backBtActionPerformed
        setVisible(false);
        new employeeHome().setVisible(true);
    }//GEN-LAST:event_backBtActionPerformed

    private void printBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printBtActionPerformed
        PrinterJob job = PrinterJob.getPrinterJob(); // PrinterJob instance banao
    job.setJobName("Flyhigh Airlines Ticket"); // Print job ka naam set karo

    job.setPrintable(new Printable() { // Printable interface ka instance create karo
        public int print(Graphics pg, PageFormat pf, int pageNum) {
            pf.setOrientation(PageFormat.LANDSCAPE); // Page format ko landscape mode mein set karo
            if (pageNum > 0) {
                return Printable.NO_SUCH_PAGE; // Agar page number greater than zero hai to NO_SUCH_PAGE return karo
            }

            Graphics2D g2 = (Graphics2D) pg; // Graphics2D object ko instantiate karo
            g2.translate(pf.getImageableX(), pf.getImageableY()); // Graphics context ki origin ko page ki shuruwat point par set karo
            g2.scale(0.47, 0.47); // Scale ko set karo (optional)

            ticketPanel.print(g2); // Ticket panel ko Graphics2D object se print karo

            return Printable.PAGE_EXISTS; // PAGE_EXISTS return karo
        }
    });

    boolean ok = job.printDialog(); // Print dialog dikhao
    if (ok) {
        try {
            job.print(); // Job ko print karo
        } catch (PrinterException ex) {
            ex.printStackTrace(); // PrinterException handle karo
        }
    }
    }//GEN-LAST:event_printBtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ticket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ticket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ticket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ticket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ticket().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBt;
    private javax.swing.JLabel classText;
    private javax.swing.JLabel classTxt;
    private javax.swing.JLabel dateText;
    private javax.swing.JLabel flightNameText;
    private javax.swing.JLabel flightNameTxt;
    private javax.swing.JLabel fromText;
    private javax.swing.JLabel fromTxt;
    private javax.swing.JLabel gateText;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel nameText;
    private javax.swing.JLabel nameTxt;
    private javax.swing.JLabel pnrText;
    private javax.swing.JButton printBt;
    private javax.swing.JLabel qrText;
    private javax.swing.JLabel seatText;
    private javax.swing.JLabel seatTxt;
    private javax.swing.JPanel ticketPanel;
    private javax.swing.JLabel timeText;
    private javax.swing.JLabel toText;
    private javax.swing.JLabel toTxt;
    private javax.swing.JLabel totalPayText;
    private javax.swing.JLabel totalPayTxt;
    // End of variables declaration//GEN-END:variables
}
